<?php

  $host = 'localhost';
  $db_name = 'rigistration_system';
  $options = [
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  ];

  $dsn = 'mysql:host=' . $host . ';dbname=' . $db_name;

  $username = 'root';
  $pass = '';

  try {
  $con = new PDO($dsn, $username, $pass, $options);

  // 1. Create Database
    $con->exec("CREATE DATABASE IF NOT EXISTS rigistration_system");
    $con->exec("USE rigistration_system");

    // 2. Create Users Table
    $con->exec("CREATE TABLE IF NOT EXISTS users (
        ID INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        premetions INT DEFAULT 0
    )");

    // 3. Insert Default Users (only if table is empty)
    $count = $con->query("SELECT COUNT(*) FROM users")->fetchColumn();

    if ($count == 0) {
        $admin_pass = password_hash('VIGO123', PASSWORD_BCRYPT);
        $user_pass  = password_hash('user123', PASSWORD_BCRYPT);

        $stmt = $con->prepare("INSERT INTO users (username, password, premetions) VALUES (?, ?, ?)");

        $stmt->execute(['VIGO', $admin_pass, 1]); // admin
        $stmt->execute(['user',  $user_pass,  0]); // normal user
    }
  } catch (PDOException $e) {
    echo 'Faild: ' . $e->getMessage();
  }
