<?php
  session_start();



  if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
  }
  if ($_SESSION['rool'] != 1) {
    http_response_code(403);
    die('Access Denied.');
  } else {
    $flag = file_get_contents('./Upload/hidden.txt');

    echo $flag;
  }
