<?php
  include './connection.php';
  session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Get The Data From POST
  $username = $_POST['username'];
  $password = $_POST['password'];
  


  $sql = 'SELECT * FROM users WHERE username = "' . $username . '" AND password = "' . $password . '"';

  $stm = $con->prepare($sql);

  $stm->execute();
  $user = $stm->fetch();

  $row = $stm->rowCount();

  if ($row) {
    $_SESSION['user_id'] = $user['ID'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['rool'] = $user['premetions'];
      header('Location: dashboard.php');
      exit();
  } else {
    echo 'Some Thing Wrong, Please Try Again.';
  }

}

// Session management and Cookie