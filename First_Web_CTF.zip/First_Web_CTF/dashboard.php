<?php
session_start();

  if (!isset($_SESSION['user_id'])) {
    echo "Accsess Denide";
    header('Location: index.php');
    exit();
  } else {
?>

<h1>Dashboard</h1>
<p>Welcome to your CTF dashboard, <?= htmlspecialchars($_SESSION['username']) ?>!</p>

<a href="logout.php">Logout</a>
</body>
</html>

<?php }