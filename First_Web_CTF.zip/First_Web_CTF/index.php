<?php 

include './connection.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auth Practice</title>
    <link rel="stylesheet" href="./style/main.css">
</head>
<body>

    <div class="auth-container">
        <!-- Login Form -->
        <div class="form-box">
            <h2>Login</h2>
            <form action="login_process.php" method="POST">
                <div class="input-group">
                    <label for="login-username">Username</label>
                    <input type="text" id="login-username" name="username" required>
                </div>
                <div class="input-group">
                    <label for="login-password">Password</label>
                    <input type="password" id="login-password" name="password" required>
                </div>
                <button type="submit" class="btn">Sign In</button>
            </form>
        </div>

    </div>

</body>
</html>