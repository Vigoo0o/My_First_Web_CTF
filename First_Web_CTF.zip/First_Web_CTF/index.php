<?php 
include './connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CTF — Auth Challenge</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./style/main.css">
</head>
<body>

    <div class="auth-container">

        <!-- Dragon Image -->
        <div class="dragon-container">
            <img src="./style/dragon.svg" alt="CTF Dragon">
        </div>

        <!-- Login Form -->
        <div class="form-box">
            <h2><span>&gt; </span>Login</h2>
            <p class="subtitle">[ enter credentials to proceed ]</p>

            <form action="login_process.php" method="POST">
                <div class="input-group">
                    <label for="login-username"><span>$ </span>Username</label>
                    <input type="text" id="login-username" name="username" placeholder="root@ctf" required>
                </div>
                <div class="input-group">
                    <label for="login-password"><span>$ </span>Password</label>
                    <input type="password" id="login-password" name="password" placeholder="••••••••" required>
                </div>
                <button type="submit" class="btn">Sign In</button>
            </form>

            <p class="status">[ system: active | attempts: monitored ]</p>
        </div>

    </div>

</body>
</html>